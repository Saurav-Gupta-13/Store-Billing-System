from tkinter import *
from PIL import Image, ImageTk
#import self as self
from tkinter import ttk, messagebox
import sqlite3


class registrationClass:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1100x500+220+130")
        self.root.title("STORE BILLING System")
        self.root.config(bg="white")
        self.root.focus_force()  # to highlight the window
        # ======================
        # all variables==============
        self.var_searchby = StringVar()
        self.var_searchtxt = StringVar()

        self.var_emp_id = StringVar()
        self.var_gender = StringVar()
        self.var_contact = StringVar()
        self.var_name = StringVar()
        self.var_DOB = StringVar()
        self.var_DOJ = StringVar()
        self.var_email = StringVar()
        self.var_password = StringVar()
        self.var_utype = StringVar()
        self.var_salary = StringVar()

        # ======title======
        title = Label(self.root, text="welcome to store billing system | First time registration", font=("goudy old style", 15), bg="#0f4d7d", fg="white").place(
            x=50, y=100, width=1000)

        # ====content============

        # ===row1=======
        lbl_empid = Label(self.root, text="EMP ID", font=("goudy old style", 15), bg="white").place(x=50, y=150)
        lbl_gender = Label(self.root, text="Gender", font=("goudy old style", 15), bg="white").place(x=350, y=150)
        lbl_contact = Label(self.root, text="Contact", font=("goudy old style", 15), bg="white").place(x=750, y=150)

        txt_empid = Entry(self.root, textvariable=self.var_emp_id, font=("goudy old style", 15),
                          bg="light yellow").place(x=150, y=150, width=180)
        # txt_gender=Entry(self.root,textvariable=self.var_gender,font=("goudy old style",15),bg="white").place(x=500,y=150,width=180)
        cmb_gender = ttk.Combobox(self.root, textvariable=self.var_gender, values=("select", "Male", "Female", "Other"),
                                  state='readonly', justify=CENTER, font=("goudy old style", 15))
        cmb_gender.place(x=500, y=150, width=180)
        cmb_gender.current(0)
        txt_contact = Entry(self.root, textvariable=self.var_contact, font=("goudy old style", 15),
                            bg="light yellow").place(x=850, y=150, width=180)

        # ===row2=======
        lbl_name = Label(self.root, text="NAME", font=("goudy old style", 15), bg="white").place(x=50, y=190)
        lbl_dob = Label(self.root, text="D.O.B", font=("goudy old style", 15), bg="white").place(x=350, y=190)
        lbl_doj = Label(self.root, text="D.O.J", font=("goudy old style", 15), bg="white").place(x=750, y=190)

        txt_name = Entry(self.root, textvariable=self.var_name, font=("goudy old style", 15), bg="light yellow").place(
            x=150, y=190, width=180)
        txt_dob = Entry(self.root, textvariable=self.var_DOB, font=("goudy old style", 15), bg="light yellow").place(
            x=500, y=190, width=180)
        txt_doj = Entry(self.root, textvariable=self.var_DOJ, font=("goudy old style", 15), bg="light yellow").place(
            x=850, y=190, width=180)

        # ===row3=======
        lbl_email = Label(self.root, text="Email", font=("goudy old style", 15), bg="white").place(x=50, y=230)
        lbl_password = Label(self.root, text="Password", font=("goudy old style", 15), bg="white").place(x=350, y=230)
        lbl_utype = Label(self.root, text="User Type", font=("goudy old style", 15), bg="white").place(x=750, y=230)

        txt_email = Entry(self.root, textvariable=self.var_email, font=("goudy old style", 15),
                          bg="light yellow").place(x=150, y=230, width=180)
        txt_pass = Entry(self.root, textvariable=self.var_password, font=("goudy old style", 15),
                         bg="light yellow").place(x=500, y=230, width=180)
        #   txt_utype=Entry(self.root,textvariable=self.var_utype,font=("goudy old style",15),bg="light yellow").place(x=850,y=230,width=180)
        cmb_utype = ttk.Combobox(self.root, textvariable=self.var_utype, values=("Admin", "Employee"), state='readonly',
                                 justify=CENTER, font=("goudy old style", 15))
        cmb_utype.place(x=850, y=230, width=180)
        cmb_utype.current(0)

        # ===row4=======
        lbl_address = Label(self.root, text="Address", font=("goudy old style", 15), bg="white").place(x=50, y=270)
        lbl_salary = Label(self.root, text="Salary", font=("goudy old style", 15), bg="white").place(x=500, y=270)

        self.txt_address = Text(self.root, font=("goudy old style", 15), bg="light yellow")
        self.txt_address.place(x=150, y=270, width=300, height=60)
        txt_salary = Entry(self.root, textvariable=self.var_salary, font=("goudy old style", 15),
                           bg="light yellow").place(x=600, y=270, width=180)





if __name__ == "__main__":
    root = Tk()
    obj = registrationClass(root)
    root.mainloop()
